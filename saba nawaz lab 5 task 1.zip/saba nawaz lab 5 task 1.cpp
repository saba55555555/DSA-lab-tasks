#include <iostream>
using namespace std;

// Node structure for the doubly linked list
struct Node {
    int data;
    Node* prev;
    Node* next;
    
    Node(int val) {
        data = val;
        prev = nullptr;
        next = nullptr;
    }
};

// Class to represent the doubly linked list
class DoublyLinkedList {
public:
    Node* head;

    DoublyLinkedList() {
        head = nullptr;
    }

    // Function to create and initialize the list with user input
    void createList(int n) {
        int value;
        cout << "Enter " << n << " marks:" << endl;
        
        for (int i = 0; i < n; i++) {
            cin >> value;
            addToBeginning(value);
        }
    }

    // Function to add a node at the beginning of the list
    void addToBeginning(int value) {
        Node* newNode = new Node(value);
        if (head == nullptr) {
            head = newNode;
        } else {
            newNode->next = head;
            head->prev = newNode;
            head = newNode;
        }
    }

    // Function to add a node after a node with value 45
    void addAfter45(int value) {
        Node* current = head;
        while (current != nullptr) {
            if (current->data == 45) {
                Node* newNode = new Node(value);
                newNode->next = current->next;
                newNode->prev = current;
                
                if (current->next != nullptr) {
                    current->next->prev = newNode;
                }
                current->next = newNode;
                cout << "Node with value " << value << " added after node with value 45." << endl;
                return;
            }
            current = current->next;
        }
        cout << "Node with value 45 not found." << endl;
    }

    // Function to print the list
    void printList() {
        Node* current = head;
        while (current != nullptr) {
            cout << current->data << " ";
            current = current->next;
        }
        cout << endl;
    }
};

int main() {
    int n, value;
    
    // Create the doubly linked list with user input
    cout << "Enter the number of nodes: ";
    cin >> n;

    DoublyLinkedList list;
    list.createList(n);

    cout << "Initial list: ";
    list.printList();

    // Add a node at the beginning
    cout << "Enter value to add at the beginning: ";
    cin >> value;
    list.addToBeginning(value);
    cout << "List after adding to the beginning: ";
    list.printList();

    // Add a node after the value 45
    cout << "Enter value to add after 45: ";
    cin >> value;
    list.addAfter45(value);
    cout << "List after adding after 45: ";
    list.printList();

����return�0;
}
