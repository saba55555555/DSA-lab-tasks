#include <iostream>
using namespace std; // Place this here
struct Node {
    int data;
    Node* next;
    Node* prev;

    Node(int val) : data(val), next(nullptr), prev(nullptr) {}
};

void deleteAtBeginning(Node* &head) {
    if (head == nullptr) return; // List is empty

    Node* temp = head;
    head = head->next; // Move head to next node

    if (head) head->prev = nullptr; // Update new head's previous pointer

    delete temp; // Free memory
}

// Function to print the list
void printList(Node* head) {
    Node* current = head;
    while (current) {
        cout << current->data << " ";
        current = current->next;
    }
    cout << endl;
}

int main() {
    // Create a simple doubly linked list: 1 <-> 2 <-> 3
    Node* head = new Node(1);
    head->next = new Node(2);
    head->next->prev = head;
    head->next->next = new Node(3);
    head->next->next->prev = head->next;

    cout << "Original list: ";
    printList(head);

    deleteAtBeginning(head);
    cout << "After deleting at beginning: ";
    printList(head);

    // Clean up remaining nodes
    deleteAtBeginning(head);
    deleteAtBeginning(head);
return 0;
}
