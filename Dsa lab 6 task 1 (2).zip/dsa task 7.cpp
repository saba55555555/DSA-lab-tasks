#include <iostream>
#include <string>
using namespace std;
 // Define the Contact structure (acting as a node in a linked list)
    struct Contact {
    string name, phone;
    Contact* next; // Pointer to the next contact
 // Constructor to initialize a contact with a name and phone number
    Contact(string n, string p) {
    name = n;
    phone = p;
   next = nullptr; 
   // Initially, next is null
    }
};
// Structure-based ContactBook to manage the linked list of contacts
struct ContactBook {
    Contact* head; // Pointer to the first contact (head of the linked list)

    // Constructor to initialize an empty ContactBook
    ContactBook() {
  head = nullptr;
    }
// Destructor to free the memory of all contacts when ContactBook is destroyed
    ~ContactBook() {
   Contact* temp;
    while (head != nullptr) { 
	// Loop through the linked list and delete each contact
  temp = head;
head = head->next;
delete temp;
}
  cout << "All contacts deleted.\n";
    }

    // Function to add a new contact (insert at the beginning)
    void addContact(string name, string phone) {
        Contact* newContact = new Contact(name, phone); // Create a new contact
        newContact->next = head; // Link the new contact to the existing list
        head = newContact; // Update head to point to the new contact
    }

    // Function to delete a contact by name
    void deleteContact(string name) {
        Contact* temp = head, *prev = nullptr;

        // Find the contact to delete
        while (temp != nullptr && temp->name != name) {
            prev = temp;
            temp = temp->next;
        }

        // If the contact is not found
        if (temp == nullptr) {
            cout << "Contact not found!\n";
            return;
        }

        // If the contact to delete is the head of the list
        if (prev == nullptr) {
            head = temp->next;
        } else {
            prev->next = temp->next;
        }

        // Delete the found contact
        delete temp;
        cout << "Contact deleted.\n";
    }

    // Function to display all contacts
    void displayContacts() {
        Contact* temp = head;
        while (temp != nullptr) {
            cout << "Name: " << temp->name << ", Phone: " << temp->phone << endl;
            temp = temp->next;
        }
    }
};

// Main function to demonstrate the ContactBook functionality
int main() {
    ContactBook book; // Create an empty ContactBook

    // Add some contacts
    book.addContact("Alice", "123456789");
    book.addContact("Bob", "987654321");

    // Display all contacts
    cout << "Contacts:\n";
    book.displayContacts();

    // Delete a contact and display updated list
    book.deleteContact("Alice");
    cout << "Updated Contacts:\n";
    book.displayContacts();

    return 0;
}

