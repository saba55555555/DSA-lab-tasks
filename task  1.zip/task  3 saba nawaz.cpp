#include <iostream>
using namespace std;
struct Node 
{
    int data;
    Node* next;
};

void insertatbeginning(Node* &head, int newData) 
{
    Node* newNode=new Node();
    newNode->data=newData;
    newNode->next=head;
    head=newNode;
}

void insertatend(Node* &head, int newData) 
{
    Node* newNode=new Node();
    newNode->data=newData;
    newNode->next=NULL;

    if(head==NULL) 
	{ 
   head=newNode;
   return;
    }

    Node* temp=head;
    while(temp->next!=NULL) 
	{ 
    temp=temp->next;
    }
    temp->next=newNode;
}


void deleteatfirst(Node* &head) 
{
    if(head==NULL) 
	{ 
   cout<<"List is empty"<<endl;
    }
    else
	{
    Node* temp=head;
    head=head->next;  
    delete temp; 
	}      
}


void printlist(Node* head)
{
    while(head!=NULL) 
	{
        cout<<head->data<<" --> ";
        head=head->next;
    }
    cout<<"NULL"<<endl;
}

int main() 
{
    Node* head=NULL;

    insertatbeginning(head, 10);
    insertatbeginning(head, 20);
    insertatbeginning(head, 30);

    cout<<"List after inserting at the beginning:\n";
    printlist(head);

    insertatend(head, 10);
    insertatend(head, 20);
    insertatend(head, 30);

    cout<<"\nList after inserting at the end:\n";
    printlist(head);

    deleteatfirst(head);

    cout<<"\nList after deleting the first node:\n";
    printlist(head);

    return 0;
}


