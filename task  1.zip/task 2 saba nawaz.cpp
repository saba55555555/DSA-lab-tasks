#include<iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

// Function to insert a node at the end of the list
void insertAtEnd(Node*& head, int newData)
{
    Node* newNode = new Node();
    newNode->data = newData;
    newNode->next = NULL;
    
    if (head == NULL) {
        head = newNode;
        return;
    }

    Node* temp = head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = newNode;
}

// Function to insert a node before a specific position
void insertBeforePosition(Node*& head, int position, int newData)
{
    // If the list is empty or position is invalid
    if (head == NULL || position < 0) {
        cout << "List is empty or invalid position!" << endl;
        return;
    }

    Node* newNode = new Node();
    newNode->data = newData;

    // If we need to insert at the head (position 0)
    if (position == 0) {
        newNode->next = head;
        head = newNode;
        return;
    }

    // Traverse the list to find the node just before the target position
    Node* temp = head;
    for (int i = 0; i < position - 1 && temp != NULL; ++i) {
        temp = temp->next;
    }

    // If the position is out of bounds
    if (temp == NULL || temp->next == NULL) {
        cout << "Invalid position!" << endl;
        return;
    }

    // Insert the new node before the target position
    newNode->next = temp->next;
    temp->next = newNode;
}

// Function to print the linked list
void printlist(Node* head)
{
    while (head != NULL) {
        cout << head->data << "->";
        head = head->next;
    }
    cout << "NULL" << endl;
}

int main()
{
    Node* head = NULL;
    
    // Inserting nodes at the end of the list
    insertAtEnd(head, 10);
    insertAtEnd(head, 20);
    insertAtEnd(head, 30);
    insertAtEnd(head, 40);
    
    cout << "Original list: ";
    printlist(head);
    
    // Inserting 25 before position 2 (i.e., before the node with value 30)
    insertBeforePosition(head, 2, 25);
    
    cout << "After inserting 25 before position 2: ";
    printlist(head);

����return�0;
}
