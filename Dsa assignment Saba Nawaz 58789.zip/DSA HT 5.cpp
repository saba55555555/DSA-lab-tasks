#include <iostream>
#include <string>
using namespace std;

// Class to represent a contact node
class Contact {
public:
    string name;
    string phoneNumber;
    Contact* next;

    // Constructor to initialize contact details
    Contact(string n, string phone) {
    name = n;
    phoneNumber = phone;
     next = nullptr;
    }
};

// Class to manage the contact book using a linked list
class ContactBook {
private:
    Contact* head;

public:
    // Constructor to initialize head pointer
    ContactBook() { 
	head = nullptr;
 }

    // Method to add a new contact
    void addContact(string name, string phoneNumber) {
        Contact* newContact = new Contact(name, phoneNumber);
        newContact->next = head;
        head = newContact;
    }

    // Method to delete a contact by name
    void deleteContact(string name) {
        if (!head) return; // Check if list is empty
        if (head->name == name) { // Delete head node if it matches
            Contact* temp = head;
            head = head->next;
            delete temp;
            return;
        }
        Contact* current = head;
        while (current->next && current->next->name != name) {
            current = current->next;
        }
        if (current->next) { // Delete matched node
            Contact* temp = current->next;
            current->next = temp->next;
            delete temp;
        }
    }

    // Method to display all contacts
    void displayContacts() {
        Contact* current = head;
        while (current) {
            cout << "Name: " << current->name << ", Phone: " << current->phoneNumber << endl;
            current = current->next;
        }
    }

    // Method to search for a contact by name
    void searchContact(string name) {
        Contact* current = head;
        while (current) {
            if (current->name == name) {
                cout << "Contact Found - Name: " << current->name << ", Phone: " << current->phoneNumber << endl;
                return;
            }
            current = current->next;
        }
        cout << "Contact not found.\n";
    }

    // Destructor to clean up dynamically allocated memory
    ~ContactBook() {
        while (head) {
            Contact* temp = head;
            head = head->next;
            delete temp;
        }
    }
};

int main() {
    ContactBook contactBook;
    
    // Adding contacts
    contactBook.addContact("Alice", "123-456-7890");
    contactBook.addContact("Bob", "987-654-3210");
    
    // Display all contacts
    cout << "Contact List:\n";
    contactBook.displayContacts();
    
    // Searching for a contact
    cout << "\nSearching for Bob:\n";
    contactBook.searchContact("Bob");
    
    // Deleting a contact
    cout << "\nDeleting Alice:\n";
    contactBook.deleteContact("Alice");
    
    // Display updated contacts
    cout << "\nUpdated Contact List:\n";
    contactBook.displayContacts();
 return 0;
}
