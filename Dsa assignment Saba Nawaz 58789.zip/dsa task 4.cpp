#include <iostream>
#include <string>
using namespace std;

// Structure to represent a student node
struct Student {
    string name;
    int rollNumber;
    int marks; // Marks attribute
    Student* next;
};

// Function to insert a student record in ascending order of Roll Number
void insertStudent(Student*& head, string name, int rollNumber, int marks) {
    Student* newStudent = new Student{name, rollNumber, marks, nullptr};
    if (!head || head->rollNumber > rollNumber) {
        newStudent->next = head;
        head = newStudent;
        return;
    }
    Student* current = head;
    while (current->next && current->next->rollNumber < rollNumber) {
        current = current->next;
    }
    newStudent->next = current->next;
    current->next = newStudent;
}

// Function to delete a student record by roll number
void deleteStudent(Student*& head, int rollNumber) {
    if (!head) return; // Check if list is empty
    if (head->rollNumber == rollNumber) { // Delete head node if it matches
        Student* temp = head;
        head = head->next;
        delete temp;
        return;
    }
    Student* current = head;
    while (current->next && current->next->rollNumber != rollNumber) {
        current = current->next;
    }
    if (current->next) { // Delete matched node
        Student* temp = current->next;
        current->next = temp->next;
        delete temp;
    }
}

// Function to display all student records
void displayStudents(Student* head) {
    Student* current = head;
    while (current) {
        cout << "Name: " << current->name << ", Roll Number: " << current->rollNumber << ", Marks: " << current->marks << endl;
        current = current->next;
    }
}

// Destructor to clean up dynamically allocated memory
void clearDatabase(Student*& head) {
    while (head) {
        Student* temp = head;
        head = head->next;
        delete temp;
    }
}

int main() {
    Student* database = nullptr; // Initialize head pointer to null
    int numberOfStudents;

    // Prompt user for the number of students
    cout << "Enter the number of students: ";
    cin >> numberOfStudents;

    // Inserting student records
    for (int i = 0; i < numberOfStudents; i++) {
        string name;
        int rollNumber, marks;

        cout << "Enter name for student " << (i + 1) << ": ";
        cin >> name;
        cout << "Enter roll number for student " << (i + 1) << ": ";
        cin >> rollNumber;
        cout << "Enter marks for student " << (i + 1) << ": ";
        cin >> marks;

        insertStudent(database, name, rollNumber, marks);
    }

    // Display all students
    cout << "\nStudent Records:\n";
    displayStudents(database);

    // Deleting a student record
    int rollToDelete;
    cout << "\nEnter Roll Number of Student to Delete: ";
    cin >> rollToDelete;
    deleteStudent(database, rollToDelete);

    // Display updated student records
    cout << "Updated Student Records:\n";
    displayStudents(database);
return 0;
}


���
