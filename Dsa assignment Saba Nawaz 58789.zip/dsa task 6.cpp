#include <iostream>
#include <string>
using namespace std;

// Structure to represent a ticket node
struct Ticket {
    string passengerName;
    int trainNumber;
    int seatNumber;
    Ticket* next;
};

// Function to reserve a ticket
void reserveTicket(Ticket*& head, string name, int trainNumber, int seatNumber) {
    Ticket* newTicket = new Ticket{name, trainNumber, seatNumber, nullptr};
    newTicket->next = head;
    head = newTicket;
}

// Function to cancel a ticket by seat number
void cancelTicket(Ticket*& head, int seatNumber) {
    if (!head) return; // Check if list is empty
    if (head->seatNumber == seatNumber) { // Delete head node if it matches
        Ticket* temp = head;
        head = head->next;
        delete temp;
        return;
    }
    Ticket* current = head;
    while (current->next && current->next->seatNumber != seatNumber) {
        current = current->next;
    }
    if (current->next) { // Delete matched node
        Ticket* temp = current->next;
        current->next = temp->next;
        delete temp;
    }
}

// Function to display all reserved tickets
void displayTickets(Ticket* head) {
    Ticket* current = head;
    while (current) {
        cout << "Passenger: " << current->passengerName << ", Train: " << current->trainNumber << ", Seat: " << current->seatNumber << endl;
        current = current->next;
    }
}

// Destructor to clean up dynamically allocated memory
void clearTickets(Ticket*& head) {
    while (head) {
        Ticket* temp = head;
        head = head->next;
        delete temp;
    }
}

int main() {
    Ticket* system = nullptr; // Initialize head pointer to null
    int numberOfTickets;

    // Prompt user for the number of tickets to reserve
    cout << "Enter the number of tickets to reserve: ";
    cin >> numberOfTickets;

    // Reserving tickets
    for (int i = 0; i < numberOfTickets; i++) {
        string name;
        int trainNumber, seatNumber;

        cout << "Enter passenger name for ticket " << (i + 1) << ": ";
        cin >> name;
        cout << "Enter train number for ticket " << (i + 1) << ": ";
        cin >> trainNumber;
        cout << "Enter seat number for ticket " << (i + 1) << ": ";
        cin >> seatNumber;

        reserveTicket(system, name, trainNumber, seatNumber);
    }

    // Display all tickets
    cout << "\nReserved Tickets:\n";
    displayTickets(system);

    // Cancel a ticket
    int seatToCancel;
    cout << "\nEnter Seat Number to Cancel: ";
    cin >> seatToCancel;
    cancelTicket(system, seatToCancel);

    // Display updated tickets
    cout << "\nUpdated Ticket List:\n";
    displayTickets(system);

    // Clean up memory
    clearTickets(system);

����return�0;
}
