#include<iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

void insertAtBeginning(Node*& head, int newData)
{
    Node* newNode = new Node();
    newNode->data = newData;
    newNode->next = head;
    head = newNode;
}

void deleteAtPosition(Node*& head, int position) 
{
    if (head == NULL) 
    {
        cout << "List is empty" << endl;
        return;
    }

    if (position == 1) // For 1-based indexing, 1 is the first node
    {
        Node* temp = head;
        head = head->next;  
        delete temp;        
        cout << "Node at position " << position << " deleted" << endl;
        return;
    }

    // traversing the list
    Node* temp = head;
    for (int i = 1; temp != NULL && i < position - 1; i++) 
    {
        temp = temp->next;
    }

    // if the position is out of range
    if (temp == NULL || temp->next == NULL) 
    {
        cout << "Position is out of range." << endl;
        return;
    }

    // deleting the node at the given position
    Node* nodeToDelete = temp->next;
    temp->next = temp->next->next;
    delete nodeToDelete;

    cout << "Node at position " << position << " deleted" << endl;
}

// Print list
void printList(Node* head) 
{
    if (head == NULL) 
    {
        cout << "List is empty" << endl;
        return;
    }
    while (head != NULL) 
    {
        cout << head->data << " -> ";
        head = head->next;
    }
    cout << "NULL" << endl;
}

int main() 
{
    Node* head = NULL;

    // Inserting data
    insertAtBeginning(head, 10);
    insertAtBeginning(head, 20);
    insertAtBeginning(head, 30);
    insertAtBeginning(head, 40);

    cout << "List before deletion:" << endl;
    printList(head);

    int position;
    cout << "Enter the position to delete: ";
    cin >> position;

    // Deleting the node at the specified position
    deleteAtPosition(head, position);

    cout << "List after deletion:" << endl;
    printList(head);
return 0;
}
