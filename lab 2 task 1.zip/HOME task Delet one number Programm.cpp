#include <iostream>
using namespace std;

int main() 
{
    int arr[5];  
    cout << "Enter 5 numbers:\n";
    for (int i = 0; i < 5; i++) 
    {
   cin >> arr[i];
    }

    int value;
    cout << "\nEnter the value you want to delete from the array: ";
    cin >> value;

    int index = -1; 

   
    if (arr[0] == value) 
    {
    index = 0;
    }
    else if (arr[1] == value) 
    {
  index = 1;
    }
    else if (arr[2] == value) 
    {
   index = 2;
    }
    else if (arr[3] == value) 
    {
    index = 3;
    }
    else if (arr[4] == value) 
    {
   index = 4;
    }
  if (index != -1) 
    {
  if (index == 0) 
   {
 for (int i = 0; i < 4; i++) 
   {
  arr[i] = arr[i + 1];
   }
}
    else if (index == 1) 
{
  for (int i = 1; i < 4; i++) 
    {
   arr[i] = arr[i + 1];
 }
  }
    else if (index == 2) 
   {
    for (int i = 2; i < 4; i++) 
   {
 arr[i] = arr[i + 1];
  }
}
   else if (index == 3) 
  {
  for (int i = 3; i < 4; i++) 
    {
  arr[i] = arr[i + 1];
}
   }
    cout << "\nUpdated Array: ";
  for (int i = 0; i < 4; i++)  
    {
   cout << arr[i] << " ";
}
    } 
    else 
    {
  cout << "\nValue not found in the array.";
    }

����return�0;
}

