#include <iostream>
using namespace std;
int main()
{ 
int a = 5;
    int *ptr = NULL;

    if (ptr == NULL)
    {
 cout << "The pointer is Null\n";
   ptr = &a; 
   int i = 50;
   float f = 9.7;
    char c = 'A';
  double d= 4000;
   void *ptr2 = &i;
    void *ptr3 = &f;
   void *ptr4 = &c;
    void *ptr5 = &d;
   cout << "Integer: " << *( t *)ptr2 << endl;
   cout << "Float: " << *(float *)ptr3 << endl;
   cout << "Character: " << *(char *)ptr4 << endl;
    cout << "Double: " << *(double *)ptr5 << endl;
   cout << "Pointer to a: " << *ptr << endl;
}
   else{
   	cout<<"The pointer is not null!";
   	
   }
   return 0;
}

