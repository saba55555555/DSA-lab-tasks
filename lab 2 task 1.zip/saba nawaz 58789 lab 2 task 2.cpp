#include<iostream>
using namespace std;
int main()
{
    int a=80;
    int b=70;
    int *ptr=&a;
    int *ptr1=&b;
    int **q=&ptr;
    int **q1=&ptr1;
    cout<<**q<<endl;
    cout<<**q1;
  return 0;
}
