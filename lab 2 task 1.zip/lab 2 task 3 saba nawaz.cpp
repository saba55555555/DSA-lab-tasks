#include <iostream>
#include<iostream>
using namespace std;
int main() 
{ 
    int numbers[] = {10, 20, 30, 40, 50};
    int *pointer = numbers;
    cout << "Initial Value at Pointer=" << *pointer << endl;
    
   cout << "After Increment=" << *pointer << endl;
 pointer--;
    cout << "After Decrement=" << *pointer << endl;
 pointer += 2;
    cout << "After Adding 2=" << *pointer << endl;
    pointer--;
    cout << "After Subtracting 1=" << *pointer << endl;
return 0;
}
